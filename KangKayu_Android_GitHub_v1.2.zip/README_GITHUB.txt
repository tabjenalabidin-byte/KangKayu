KangKayu Android v1.1

Revisi:
1. Formulir Bahan/Kayu dihapus.
2. Nomor HP dapat dipilih dari kontak telepon Android.
3. Foto order dapat dipilih lebih dari satu.
4. Menu Pengaturan di navbar diganti menjadi Katalog.
5. Katalog berisi foto, nama, kategori, harga, dan keterangan produk.
6. Tambah/edit/hapus produk dilakukan melalui tombol Pengaturan di dalam Katalog.
7. Foto katalog juga mendukung lebih dari satu foto.

GitHub:
- Upload isi project ini ke root repository, atau upload ZIP dan gunakan workflow sesuai struktur project.
- Workflow ada di .github/workflows/build-apk.yml.
- Artifact hasil build: KangKayu-APK.

KangKayu v1.2
- Foto dashboard dan katalog bisa dibuka dalam viewer layar penuh.
- Viewer mendukung tombol zoom, double-tap, scroll zoom, dan pinch zoom.
- Ditambahkan menu Rekap Bulanan.
- Rekap menampilkan jumlah order masuk, uang masuk berdasarkan DP, dan total nilai order per bulan.
- Tahun rekap bisa dipilih.
- Order lama yang belum punya createdAt memakai ID timestamp sebagai tanggal order.
